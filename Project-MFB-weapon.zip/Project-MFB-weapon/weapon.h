//
// Created by kyli8 on 19/06/2023.
//

#ifndef WORKSPACE_WEAPON_H
#define WORKSPACE_WEAPON_H


void changeWeapon(Weapon a, Player *player);
void fire(Ennemie *a);
void reload(Player *player);

#endif //WORKSPACE_WEAPON_H
