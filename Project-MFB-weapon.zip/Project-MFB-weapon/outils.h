//
// Created by kyli8 on 12/06/2023.
//

#ifndef WORKSPACE_OUTILS_H
#define WORKSPACE_OUTILS_H



double Rdistance(double x1, double y1, double x2, double y2);
void iaEnnemie(Ennemie a);
void gereEnnemie(Ennemie *tab, int number);
unsigned long long current_time_ms();


#endif //WORKSPACE_OUTILS_H
